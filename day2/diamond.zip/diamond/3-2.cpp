#include <stdio.h>
#include <pthread.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <semaphore.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#define SNAME "/mysemaphore"
#define SNAME2 "/mysemaphore2"
int main(){
    sem_t *sem = sem_open(SNAME, 0);
  //  sem_t *sem2 = sem_open(SNAME2, 0);

    int k = 10;
    // system("./a2.out");
    //printf("Lets go\n");
  // sem_post(sem);
    //system("./a2.out");
    while(k--){
      sem_wait(sem);

      key_t key = ftok("/tmp",65);
      int shmid = shmget(key,1024,0666|IPC_CREAT);
      int* X = (int *) shmat(shmid,(void*)0,0);
      int t = *X;
      printf("Reading from X by proc 2 : %d\n",t);

      key_t key2 = ftok("/y",60);
      int shmid2 = shmget(key2,1000,0666|IPC_CREAT);
      int* Y = (int *) shmat(shmid2,(void*)0,0);
      t++;
      *Y = t;
      //shmdt(Y);
      printf("Writing in Y by proc 2 : %d\n",t);
      //sem_post(sem2);
      //sem_wait(sem);
      //int t=1;
      //shmdt(X);
      //printf("%d\n",*Y );
      sem_post(sem);
      sleep(1);
   }

    //sleep(3);
    key_t key = ftok("/tmp",65);
    int shmid = shmget(key,1024,0666|IPC_CREAT);
    key_t key2 = ftok("/y",60);
    int shmid2 = shmget(key2,1000,0666|IPC_CREAT);
   shmctl(shmid,IPC_RMID,NULL);
    shmctl(shmid2,IPC_RMID,NULL);
     sem_destroy(sem);

    return 0;
}
//Compile : gcc semaphore.cpp -lpthread -lrt
