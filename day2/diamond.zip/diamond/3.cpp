#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#define SNAME "/mysemaphore"
#define SNAME2 "/mysemaphore2"

int main(){
    sem_t *sem = sem_open(SNAME, O_CREAT, 0644, 1);
    if (sem == SEM_FAILED) {
    perror("ERROR:");
    exit(1);
    }
    // sem_t *sem2 = sem_open(SNAME2, O_CREAT, 0644, 1);
    // if (sem == SEM_FAILED) {
    // perror("ERROR:");
    // exit(1);
    // }




    int k = 10;
    // system("./a2.out");
    //printf("Lets go\n");
  // sem_post(sem);
    sem_wait(sem);
    key_t key = ftok("/tmp",65);
    int shmid = shmget(key,1024,0666|IPC_CREAT);
    int* X = (int *) shmat(shmid,(void*)0,0);
    *X = 1;
    printf("Writing in X by proc1 : 1\n" );
  //  shmdt(X);
    // key_t key2 = ftok("/y",60);
    // int shmid2 = shmget(key2,1000,0666|IPC_CREAT);
    // int* Y = (int *) shmat(shmid2,(void*)0,0);
    // *Y = 1;
    // shmdt(Y);
    sem_post(sem);

    pid_t pid = fork();
   if(pid == 0){
     static char *argv[]={"./a2.out",NULL};
     execv(argv[0],argv);
     exit(127);
   }
   else{
    while(k--){
      sleep(1);
      sem_wait(sem);
      key_t key2 = ftok("/y",60);
      int shmid2 = shmget(key2,1000,0666|IPC_CREAT);
      int* Y = (int *) shmat(shmid2,(void*)0,0);
      int t = *Y;
      //shmdt(Y);
      printf("Reading in Y by proc 1 : %d\n",t);
      //sem_post(sem2);
      t++;
      //sem_wait(sem);
      //int t=1;
      printf("Writing in X by proc 1 : %d\n",t);
      key_t key = ftok("/tmp",65);
      int shmid = shmget(key,1024,0666|IPC_CREAT);
      int* X = (int *) shmat(shmid,(void*)0,0);
      *X = t;
      //shmdt(X);
      //printf("%d\n",*Y );
      sem_post(sem);
      //sleep(1);
   }

    //sleep(3);
  //  shmctl(shmid,IPC_RMID,NULL);
  //  shmctl(shmid2,IPC_RMID,NULL);
     sem_destroy(sem);
   }
    // sem_destroy(sem2);

    return 0;
}
//Compile : gcc sema_proc1.cpp -lpthread -lrt
