#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <fstream>

sem_t mutex;

// int readline(FILE *f, char *buffer, size_t len)
// {
//    char c;
//    int i;
//
//    memset(buffer, 0, len);
//
//    for (i = 0; i < len; i++)
//    {
//       int c = fgetc(f);
//
//       if (!feof(f))
//       {
//          if (c == '\r')
//             buffer[i] = 0;
//          else if (c == '\n')
//          {
//             buffer[i] = 0;
//
//             return i+1;
//          }
//          else
//             buffer[i] = c;
//       }
//       else
//       {
//          //fprintf(stderr, "read_line(): recv returned %d\n", c);
//          return -1;
//       }
//    }
//
//    return -1;
// }

int main(){
   char buf[11];
   buf[10] = '\0';
  int file=open("text.txt",O_RDONLY);
  // fstream fin;
  // fin.open("text.txt");
  //FILE *file = fopen ( "text.txt", "r" );
  //FILE* fptr = fopen("text.txt", "r");
  read(file,buf,10);
  printf("%s\n",buf);
  sem_init(&mutex, 0, 1);

  int c=fork();
  if(c>0) {
    // sleep(0.5);
    int k=2;
    while(k--){
      sleep(1);
      sem_wait(&mutex);
      read(file,buf,10);
      //read(fd,buf,10);
      printf("From parent : %s\n",buf);
      sem_post(&mutex);
    }
  }
  else {
    int k=2;
    while(k--){
      sem_wait(&mutex);
      read(file,buf,10);
      //read(fd,buf,10);
      printf("From child : %s\n",buf);
      sem_post(&mutex);
      sleep(1);
    }
  }
  return 0;
}
